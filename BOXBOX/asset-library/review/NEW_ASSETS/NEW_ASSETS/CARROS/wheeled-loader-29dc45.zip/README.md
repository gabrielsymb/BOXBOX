# Wheeled Loader

https://polyfork.dev/asset/wheeled-loader-29dc45

A parametric low-poly model for three.js. One import, no loader, no textures,
one draw call. `createAsset()` returns a ready `THREE.Group`.

## What is in this folder

| file | what it is |
| --- | --- |
| `index.html` | a complete working page: **double-click it** |
| `wheeled-loader-29dc45.mjs` | the model as an ES module, with every option below |
| `wheeled-loader-29dc45.glb` | the same model baked, for Unity, Godot, Blender and glTF loaders |
| `LICENSE.txt` | the terms, file by file: which licence each file is under |

## Run it

Double-click `index.html`. It needs an internet connection the first time,
because three.js is pulled from unpkg.com.

It carries its own copy of the model code so that it works from a `file://`
URL, where browsers refuse to load ES modules. If you would rather edit
`wheeled-loader-29dc45.mjs` and see the page pick up your changes, serve the folder
and it will import the file instead of the copy:

```
python3 -m http.server     # then open http://localhost:8000
```

## Use it in your own scene

```js
import { createAsset } from './wheeled-loader-29dc45.mjs';
scene.add(createAsset());
```

The bare `three` specifiers resolve through any bundler (Vite, webpack, esbuild),
or through an importmap in your page:

```html
<script type="importmap">
{ "imports": { "three": "https://unpkg.com/three@0.180.0/build/three.module.js",
               "three/addons/": "https://unpkg.com/three@0.180.0/examples/jsm/" } }
</script>
```

Prefer the GLB? `new GLTFLoader().load('wheeled-loader-29dc45.glb', g => scene.add(g.scene))`.
The module is the smaller and more flexible of the two: it carries the options
below, the GLB is one frozen configuration of them.

## Options

```js
createAsset({
  colorway: 'plant-yellow',
  wear: 0.3,
  lift: 0.5,
  bucket: 0.5,
  steer: 0.5,
  load: 0,
  body: '#E3A31B',
  frame: '#3A4146',
  steel: '#9BA5AB',
  tyre: '#15181A',
  glass: '#262B2F',
  lamp: '#F2F7FF',
  beacon: '#EF6A1E',
  spoil: '#6B5842',
  mud: '#8E7859',
});
```

| option | type | default | accepts | what it does |
| --- | --- | --- | --- | --- |
| `colorway` | choice | `'plant-yellow'` | `'plant-yellow'`, `'hire-white'`, `'works-grey'`, `'site-green'`, `'clay-brown'` | curated kit-coherent paint scheme, the same five the kit's skid steer and backhoe offer so the plant reads as one fleet. It moves the painted body and the bright hydraulic hardware together: plant-yellow is the shipped machine and the kit's one plant accent; hire-white an ex-hire machine in works off-white; works-grey an unpainted grey works machine; site-green a municipal dark green; clay-brown an owner-operator earth brown. The dark grey joint and steelwork, the tyres, the glazing, the lamp and beacon lenses, the spoil and the mud never move in any scheme. |
| `wear` | range | `0.3` | `0` to `1` | 0 new and clean, 1 old and site-worn: faded paint, mud, dust, rust and small chips; the object itself never changes. |
| `lift` | range | `0.5` | `0` to `1` | how high the two yellow LIFT ARMS are raised about their tower pins, 0 parked to 1 working. 0.5 (the shipped default) is CARRY: the arms three degrees off their stops, so the bucket rides a hand's width off the ground. Anything from 0 to 0.45 is PARKED, the arms right down and the bucket sitting on the ground. Above 0.5 they climb steadily, a little over halfway up at 0.75, and reach the top of their travel at 1: seventy-five degrees up with the bucket hinge pins about 3.2 m off the ground, the WORKING load height. The arms, the cross tube, the central bellcrank, the tilt cylinder, the link, both lift cylinders and the whole bucket move together as one linkage; the bucket keeps the attitude to the ground that `bucket` asks for while the arms move, and if a pose would push the bucket into the ground the arms float up just enough to clear it. |
| `bucket` | range | `0.5` | `0` to `1` | the BUCKET's attitude to the ground, turned at its hinge pins on the arm tips. 0.5 (the shipped default) carries it rolled back about twelve degrees. Lower values tip it forward: at about 0.43 its floor is level, which with the arms down is the parked bucket lying flat on the ground, and from 0.2 down it is tipped as far forward as it goes, teeth down, to dump. The bucket stops sixty degrees forward of the arms and the arms float up until the teeth clear the ground, so from the shipped arm height it ends about thirty-six degrees nose-down with the hinge pins about 1.25 m up, and less nose-down the higher the arms are: at the top of the lift it only comes down to fifteen degrees rolled back. A bucket tipped more than five degrees nose-down carries no load. Higher values roll it back to its stop, thirty degrees past the arms: about twenty degrees more while the arms are low, reached by 0.65, and up to forty degrees to the ground once the arms are raised. The bucket's hinge ears and the link's centre bracket stay on their pins at every value. |
| `steer` | range | `0.5` | `0` to `1` | the ARTICULATION: the whole front unit (loader towers, front fenders, front wheels, lift arms, linkage and bucket) swings about the vertical centre pivot between the axles while the rear unit and cab stay put, exactly as the real machine steers. 0.5 (the shipped default) is straight ahead; 0 is full lock to the machine's right, 1 full lock to its left, 35 degrees either way, three and a half degrees a step. The dark grey hinge yoke and its two pins stay engaged at every value. |
| `load` | range | `0` | `0` to `1` | how much dug spoil the bucket carries. 0 (the shipped default) is an empty bucket, its yellow floor and back showing. Anything above 0 is a load of brown earth between the side plates with four clods standing out of it: level with the side plates up to 0.2, then heaped a little higher at every step until at 1 it stands well above them; from 0.6 up a fifth clod rides the ridge of the heap. A bucket tipped more than five degrees nose-down (`bucket` at 0.4 or less with the arms low) has shed its load and stays empty whatever this says; with `lift` at 0.85 or more the bucket cannot tip that far, so the load stays in. The load is its own detachable `load` group inside the bucket, so a game can drop it when the bucket tips, and the bucket is closed behind it. |
| `body` | color | `'#E3A31B'` | any hex or `THREE.Color` | albedo of every painted structural mass: the engine hood, the counterweight, the rear fenders and walkways, the cab base and the thick roof slab, both chassis frames, the loader towers, the front fenders, both lift arms, the cross tube, the bellcrank and link, every hydraulic cylinder BARREL, the whole bucket with its teeth, the grille and vent surrounds and the four wheel rims. The kit's single plant-yellow accent and the colour this machine is recognised by from 10 m. |
| `frame` | color | `'#3A4146'` | any hex or `THREE.Color` | albedo of the dark grey steelwork: the articulation hinge (yoke plates and pivot boss), both axle housings, the tower pin tube, the cab's window frames and the empty cab's seat base, console and steering, the access ladders, the fender handrails, the mirrors, the exhaust stack, the louvres of the rear grille and the flank vents, the fender brackets, every lamp housing, the beacon base and the tow hitch. The second read after the yellow, and what makes the joint read as a joint. |
| `steel` | color | `'#9BA5AB'` | any hex or `THREE.Color` | albedo of the bright unpainted hardware: every hydraulic ROD sliding out of its yellow barrel, the pin heads on the tower and bucket pins, the articulation pin caps, the wheel hub caps, wheel nuts and valve stems. A clear value rung off the paint, because a bright rod out of a barrel is what makes a ram read as a ram. |
| `tyre` | color | `'#15181A'` | any hex or `THREE.Color` | albedo of the four tyre carcasses and their block lugs (while clean), and of the empty seat cushion and backrest inside the cab. Near-black but never pure black, so the wheels still take a highlight. |
| `glass` | color | `'#262B2F'` | any hex or `THREE.Color` | tint of the cab glazing: the raked windscreen, the two side windows each side and the rear window, drawn as see-through tinted panes set into the dark frames so the empty seat and steering read through them. Never lit at night: the cab is empty. |
| `lamp` | color | `'#F2F7FF'` | any hex or `THREE.Color` | albedo of the four cold work-white lenses: the two work lamps on the front edge of the cab roof and the two driving lamps on posts at the back of the front fenders. The kit's ONE work white, worn by nothing else in any colorway, and the zone `night.lamp` burns. |
| `beacon` | color | `'#EF6A1E'` | any hex or `THREE.Color` | albedo of every warning lens: the faceted beacon dome on the cab roof, the two tail lamps on the back of the counterweight and the two small side markers on the driving lamps. The kit's ONE warning amber, hi-vis orange as a lens moulding rather than as paint, and the zone `night.beacon` burns. |
| `spoil` | color | `'#6B5842'` | any hex or `THREE.Color` | albedo of the load of dug earth in the bucket and the clods standing out of it, which exist only while `load` is above 0 and the bucket is not tipped to dump: about level with the side plates at 0.2, heaped well above them at 1. At `load` 0, the shipped default, there is no load and this knob paints nothing. |
| `mud` | color | `'#8E7859'` | any hex or `THREE.Color` | albedo of the caked site mud that `wear` packs into the tyres: it builds in the tread between the lugs from `wear` 0.4 and fills it by 0.6, then creeps onto the tyre shoulders from 0.7 and covers them by 1; the lugs and sidewalls stay rubber. At `wear` 0.3 and below, the shipped default included, the tyres are clean and this knob paints nothing. |

## Specs

3,016 triangles, 2 material, 2.8 × 3.23 × 7.12 m, real-world scale.

Animatable parts (pivots sit at the hinge or axle): steer-hitch, lift-arm, tilt, wheel-fl, wheel-fr, wheel-rl, wheel-rr.

## Aiming this arm

It is a rooted chain — a slew (`steer-hitch`) carrying two booms (`lift-arm`, `tilt`) — and `walk.mjs` in this folder points it:

```js
import { arm } from './walk.mjs';

const machine = createAsset();
scene.add(machine);
const boom = arm(machine);

// send the tip wherever you like; it returns how far short it fell, in metres
boom.reachTo(new THREE.Vector3(2, 3, 1));
```

The slew and both booms solve together, and the tip stops at the joint ranges this
model declares rather than reaching past them, so it never draws a pose it does not
have. Reach is **2.985 m** from the base. If the arm has a levelling wrist
the tool stays flat as the booms fold, which is what keeps a load from tipping.

Not using three.js? The same numbers are in `https://polyfork.dev/api/assets/wheeled-loader-29dc45`
under `arm`: the chain, the segment lengths, where the tip sits and how far it reaches.

## Building this with an AI agent?

Point it at https://polyfork.dev/prompt.txt: the whole catalogue as working
instructions, no key needed to browse. There is an MCP server too, at https://polyfork.dev/mcp.

## License

```
Licence

THE MESH FILES (.glb, .fbx, .usdz, .usda, .obj, .mtl) are yours under
either licence, your choice:

1. CC BY 4.0, https://creativecommons.org/licenses/by/4.0/
   Use, share, modify, re-upload and sell them, commercially too, as long as you
   credit Polyfork and say if you changed them. The credit line:
   Wheeled Loader by Polyfork (https://polyfork.dev/asset/wheeled-loader-29dc45), CC BY 4.0

2. The Polyfork licence, below: no credit needed, but no redistributing the files.

EVERYTHING ELSE here, the ES modules (.mjs) above all, is under the
Polyfork licence only. CC BY does not cover it.

The Polyfork licence

Use these files in personal and commercial projects: games, apps, websites, client
work, products you sell. Modify freely. No attribution required. Do not resell or
redistribute the files themselves as assets, or use them to build or train a
COMMERCIAL 3D asset generator: a model, service or pipeline that produces 3D assets
and that you sell or offer to others. Personal experiments, research and learning
are fine. Breaking these terms can end your licence and your access, without a
refund.

Full terms: https://polyfork.dev/licensing
```
